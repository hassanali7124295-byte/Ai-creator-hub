# AI Creator Hub v1.0

An AI-powered creator assistant app built with Flutter — AI chat, image generation,
video prompt generation, script writing, and more creator tools, wrapped in a
modern Material 3 UI.

## Current status: Step 1 of the build

This repo currently contains:
- `pubspec.yaml` — dependencies for state management, theming, and networking
- `lib/` — app entry point, Material 3 theme system, home dashboard, bottom
  navigation shell, and placeholder screens for each upcoming feature

The `android/` platform folder is **not committed yet** — it's generated
automatically by the CI workflow (see below), so you don't need a local
Flutter installation to get a build. It will be added to the repo once
Phase 4 (AdMob) needs hand-edited native manifest changes.

## Running locally (if you have Flutter installed)

```bash
flutter create . --platforms=android --org com.aicreatorhub
flutter pub get
flutter run
```

## Building the APK via GitHub Actions

Every push to `main` (and manual runs via the **Actions** tab →
**Build Android APK** → **Run workflow**) will:

1. Set up JDK 17 and the Flutter stable channel
2. Scaffold the `android/` folder if it isn't present
3. Run `flutter pub get`
4. Run `flutter analyze` (non-blocking)
5. Build a release APK
6. Upload it as a workflow artifact named **ai-creator-hub-release-apk**

Download the APK from the workflow run's **Artifacts** section once it
finishes — no local Flutter setup required.

## Roadmap

- **Phase 2** — AI Chat, Script Writer, Image Generator, Video Prompt Generator
- **Phase 3** — Thumbnail Maker, Translator, Resume Builder, PDF Summarizer
- **Phase 4** — Google AdMob integration (banner / interstitial / reward)
- **Phase 5** — App icon, splash screen, release signing, Play Store prep
