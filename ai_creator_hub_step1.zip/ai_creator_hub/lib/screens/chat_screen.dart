import 'package:flutter/material.dart';
import '../widgets/coming_soon_placeholder.dart';

/// AI Chat screen — will host the Gemini-powered chat UI in Phase 2.
class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Chat')),
      body: const ComingSoonPlaceholder(
        icon: Icons.chat_bubble_outline_rounded,
        title: 'AI Chat',
        phaseLabel: 'Phase 2',
      ),
    );
  }
}
